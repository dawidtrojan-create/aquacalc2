import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  try {
    await NotificationService.init();
  } catch (e) {
    debugPrint("Notification init error: $e");
  }

  runApp(const AquaCalcApp());

}

class AquaCalcApp extends StatelessWidget {
  const AquaCalcApp({super.key});

  @override
  Widget build(BuildContext context) {

    return MaterialApp(

      title: 'AquaCalc',

      debugShowCheckedModeBanner: false,

      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),

      home: const HomeScreen(),

    );

  }

}