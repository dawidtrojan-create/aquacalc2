import 'package:flutter/material.dart';
import '../widgets/app_background.dart';
import '../utils/number_parser.dart';

class RoMixScreen extends StatefulWidget {
  const RoMixScreen({super.key});

  @override
  State<RoMixScreen> createState() => _RoMixScreenState();
}

class _RoMixScreenState extends State<RoMixScreen> {

  final volumeController = TextEditingController();

  final tapGhController = TextEditingController();
  final tapKhController = TextEditingController();

  final targetGhController = TextEditingController();
  final targetKhController = TextEditingController();

  double roResult = 0;
  double tapResult = 0;

  InputDecoration decoration(String label) {

    return InputDecoration(

      labelText: label,

      labelStyle: const TextStyle(color: Colors.black),

      filled: true,
      fillColor: Colors.white,

      enabledBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.black),
      ),

      focusedBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.black, width: 2),
      ),

    );

  }

  void calculate() {

    final volume = parseNumber(volumeController.text);

    final tapGh = parseNumber(tapGhController.text);
    final tapKh = parseNumber(tapKhController.text);

    final targetGh = parseNumber(targetGhController.text);
    final targetKh = parseNumber(targetKhController.text);

    if (volume <= 0 || tapGh <= 0 || tapKh <= 0) {

      setState(() {
        roResult = 0;
        tapResult = 0;
      });

      return;
    }

    // liczymy na podstawie GH (standardowa metoda)
    final tap = volume * targetGh / tapGh;
    final ro = volume - tap;

    setState(() {
      tapResult = tap;
      roResult = ro;
    });

  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Kalkulator RO / kran",

      child: Padding(

        padding: const EdgeInsets.all(16),

        child: ListView(

          children: [

            TextField(
              controller: volumeController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Objętość końcowa (L)"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: tapGhController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("GH kranu"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: tapKhController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("KH kranu"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: targetGhController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Docelowe GH"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: targetKhController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Docelowe KH"),
            ),

            const SizedBox(height: 20),

            ElevatedButton(

              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
              ),

              onPressed: calculate,

              child: const Text("Oblicz"),

            ),

            const SizedBox(height: 20),

            Text(
              "RO: ${roResult.toStringAsFixed(2)} L",
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            Text(
              "Kran: ${tapResult.toStringAsFixed(2)} L",
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

          ],

        ),

      ),

    );

  }

}