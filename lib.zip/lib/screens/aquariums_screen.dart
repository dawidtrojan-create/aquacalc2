import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../widgets/app_background.dart';
import '../services/premium_service.dart';
import 'premium_screen.dart';

class AquariumsScreen extends StatefulWidget {
  const AquariumsScreen({super.key});

  @override
  State<AquariumsScreen> createState() => _AquariumsScreenState();
}

class _AquariumsScreenState extends State<AquariumsScreen> {

  List<Map<String, String>> aquariums = [];
  String activeAquarium = "";

  final nameController = TextEditingController();
  final volumeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadAquariums();
  }

  Future<void> loadAquariums() async {

    final prefs = await SharedPreferences.getInstance();

    final saved = prefs.getStringList("aquariums") ?? [];

    aquariums = saved.map((e) {

      final parts = e.split("|");

      return {
        "name": parts[0],
        "volume": parts.length > 1 ? parts[1] : "",
      };

    }).toList();

    activeAquarium = prefs.getString("activeAquarium") ?? "";

    setState(() {});
  }

  Future<void> saveAquariums() async {

    final prefs = await SharedPreferences.getInstance();

    final list = aquariums
        .map((a) => "${a["name"]}|${a["volume"]}")
        .toList();

    await prefs.setStringList("aquariums", list);
  }

  Future<void> setActive(String name) async {

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString("activeAquarium", name);

    setState(() {
      activeAquarium = name;
    });
  }

  Future<void> addAquarium() async {

    final name = nameController.text.trim();
    final volume = volumeController.text.trim();

    if (name.isEmpty || volume.isEmpty) return;

    final isPremium = await PremiumService.isPremium();

    // FREE user może mieć tylko 1 akwarium
    if (!isPremium && aquariums.length >= 1) {

      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => const PremiumScreen(),
        ),
      );

      return;
    }

    aquariums.add({
      "name": name,
      "volume": volume,
    });

    await saveAquariums();

    nameController.clear();
    volumeController.clear();

    setState(() {});
  }

  Future<void> deleteAquarium(int index) async {

    final deletedName = aquariums[index]["name"];

    aquariums.removeAt(index);

    if (activeAquarium == deletedName) {

      activeAquarium = "";

      final prefs = await SharedPreferences.getInstance();
      await prefs.remove("activeAquarium");

    }

    await saveAquariums();

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Moje akwaria",

      child: Scaffold(

        backgroundColor: Colors.transparent,

        body: Padding(

          padding: const EdgeInsets.all(16),

          child: Column(

            children: [

              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.black),
                decoration: const InputDecoration(
                  labelText: "Nazwa akwarium",
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: volumeController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.black),
                decoration: const InputDecoration(
                  labelText: "Objętość (L)",
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),

              const SizedBox(height: 10),

              ElevatedButton(
                onPressed: addAquarium,
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.black,
                ),
                child: const Text("Dodaj akwarium"),
              ),

              const SizedBox(height: 20),

              Expanded(

                child: ListView.builder(

                  itemCount: aquariums.length,

                  itemBuilder: (context, index) {

                    final aquarium = aquariums[index];
                    final isActive =
                        aquarium["name"] == activeAquarium;

                    return Card(

                      color: Colors.white,

                      child: ListTile(

                        title: Text(
                          aquarium["name"]!,
                          style: const TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        subtitle: Text(
                          "${aquarium["volume"]} L",
                          style: const TextStyle(
                            color: Colors.black,
                          ),
                        ),

                        leading: IconButton(

                          icon: Icon(
                            isActive
                                ? Icons.check_circle
                                : Icons.circle_outlined,
                            color: isActive
                                ? Colors.green
                                : Colors.grey,
                          ),

                          onPressed: () =>
                              setActive(aquarium["name"]!),

                        ),

                        trailing: IconButton(

                          icon: const Icon(
                            Icons.delete,
                            color: Colors.black,
                          ),

                          onPressed: () =>
                              deleteAquarium(index),

                        ),

                      ),

                    );

                  },

                ),

              ),

            ],

          ),

        ),

      ),

    );

  }

}