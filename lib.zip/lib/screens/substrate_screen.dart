import 'package:flutter/material.dart';
import '../widgets/app_background.dart';
import '../utils/number_parser.dart';

class SubstrateScreen extends StatefulWidget {
  const SubstrateScreen({super.key});

  @override
  State<SubstrateScreen> createState() => _SubstrateScreenState();
}

class _SubstrateScreenState extends State<SubstrateScreen> {

  final lengthController = TextEditingController();
  final widthController = TextEditingController();
  final frontController = TextEditingController();
  final backController = TextEditingController();

  double liters = 0;
  double kg = 0;

  void calculate() {

    final length = parseNumber(lengthController.text);
    final width = parseNumber(widthController.text);
    final front = parseNumber(frontController.text);
    final back = parseNumber(backController.text);

    final avgHeight = (front + back) / 2;

    final volume = (length * width * avgHeight) / 1000;

    setState(() {

      liters = volume;

      // 1L ≈ 1.5kg
      kg = volume * 1.5;

    });

  }

  InputDecoration decoration(String label) {

    return InputDecoration(
      filled: true,
      fillColor: Colors.white,

      labelText: label,

      labelStyle: const TextStyle(color: Colors.black),

      enabledBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.black),
      ),

      focusedBorder: const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.black, width: 2),
      ),
    );

  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Podłoże ze spadkiem",

      child: Padding(

        padding: const EdgeInsets.all(16),

        child: ListView(

          children: [

            TextField(
              controller: lengthController,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Długość akwarium (cm)"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: widthController,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Szerokość akwarium (cm)"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: frontController,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Grubość przód (cm)"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: backController,
              style: const TextStyle(color: Colors.black),
              decoration: decoration("Grubość tył (cm)"),
            ),

            const SizedBox(height: 20),

            ElevatedButton(

              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
              ),

              onPressed: calculate,

              child: const Text("Oblicz"),

            ),

            const SizedBox(height: 20),

            Text(
              "Potrzebne podłoże:",
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              "${liters.toStringAsFixed(1)} litrów",
              style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            Text(
              "${kg.toStringAsFixed(1)} kg",
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
              ),
            ),

          ],

        ),

      ),

    );

  }

}