import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

import '../widgets/app_background.dart';
import '../models/water_test_result.dart';
import '../models/water_parameter.dart';
import '../services/full_water_test_service.dart';

class ChartsScreen extends StatefulWidget {
  const ChartsScreen({super.key});

  @override
  State<ChartsScreen> createState() => _ChartsScreenState();
}

class _ChartsScreenState extends State<ChartsScreen> {

  List<WaterTestResult> history = [];

  String selectedParameter = "NO3";

  final parameters = [

    const WaterParameter(
      name: "NO3",
      unit: "ppm",
      min: 0,
      optimalMin: 10,
      optimalMax: 25,
      max: 50,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "PO4",
      unit: "ppm",
      min: 0,
      optimalMin: 0.5,
      optimalMax: 2,
      max: 5,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "Fe",
      unit: "ppm",
      min: 0,
      optimalMin: 0.05,
      optimalMax: 0.2,
      max: 0.5,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "K",
      unit: "ppm",
      min: 0,
      optimalMin: 10,
      optimalMax: 30,
      max: 50,
      testDurationSeconds: 60,
    ),

  ];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {

    final data = await FullWaterTestService.getHistory();

    data.sort((a, b) => a.date.compareTo(b.date));

    setState(() {
      history = data;
    });

  }

  List<FlSpot> getSpots() {

    List<FlSpot> spots = [];

    int index = 0;

    for (final test in history) {

      final value = test.values[selectedParameter];

      if (value != null) {

        spots.add(
          FlSpot(index.toDouble(), value),
        );

        index++;

      }

    }

    return spots;

  }

  String formatDate(DateTime date) {

    return "${date.day.toString().padLeft(2, '0')}."
           "${date.month.toString().padLeft(2, '0')}."
           "${date.year}";

  }

  @override
  Widget build(BuildContext context) {

    final spots = getSpots();

    return AppBackground(

      title: "Wykresy parametrów",

      child: Column(

        children: [

          Padding(

            padding: const EdgeInsets.all(16),

            child: DropdownButton<String>(

              dropdownColor: Colors.black,

              value: selectedParameter,

              style: const TextStyle(
                color: Colors.white,
              ),

              items: parameters.map((p) {

                return DropdownMenuItem(

                  value: p.name,

                  child: Text(p.name),

                );

              }).toList(),

              onChanged: (value) {

                if (value != null) {

                  setState(() {
                    selectedParameter = value;
                  });

                }

              },

            ),

          ),

          Expanded(

            child: Padding(

              padding: const EdgeInsets.all(16),

              child: LineChart(

                LineChartData(

                  backgroundColor: Colors.transparent,

                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (_) =>
                        const FlLine(
                          color: Colors.white24,
                          strokeWidth: 1,
                        ),
                  ),

                  borderData: FlBorderData(
                    show: true,
                    border: const Border(
                      left: BorderSide(color: Colors.white),
                      bottom: BorderSide(color: Colors.white),
                    ),
                  ),

                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 42,
                        getTitlesWidget: (value, meta) {

                          return Text(
                            value.toStringAsFixed(1),
                            style: const TextStyle(
                              color: Colors.white,
                            ),
                          );

                        },
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: false,
                      ),
                    ),
                    rightTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    topTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),

                  lineTouchData: LineTouchData(

                    touchTooltipData: LineTouchTooltipData(

                      getTooltipItems: (spots) {

                        return spots.map((spot) {

                          final test = history[spot.x.toInt()];

                          return LineTooltipItem(

                            "${formatDate(test.date)}\n"
                            "${spot.y.toStringAsFixed(2)}",

                            const TextStyle(
                              color: Colors.lightBlueAccent,
                            ),

                          );

                        }).toList();

                      },

                    ),

                  ),

                  lineBarsData: [

                    LineChartBarData(

                      spots: spots,

                      isCurved: true,

                      color: Colors.lightBlueAccent,

                      barWidth: 3,

                      dotData: FlDotData(
                        show: true,
                      ),

                    ),

                  ],

                ),

              ),

            ),

          ),

        ],

      ),

    );

  }

}