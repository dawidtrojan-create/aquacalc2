import 'package:flutter/material.dart';
import '../widgets/app_background.dart';
import '../services/premium_service.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {

  bool loading = false;
  bool isPremium = false;

  @override
  void initState() {
    super.initState();
    checkPremium();
  }

  Future<void> checkPremium() async {

    final premium = await PremiumService.isPremium();

    setState(() {
      isPremium = premium;
    });

  }

  Future<void> buy() async {

    setState(() {
      loading = true;
    });

    try {

      await PremiumService.buyPremium();

    } catch (_) {}

    setState(() {
      loading = false;
    });

  }

  Future<void> restore() async {

    await PremiumService.restorePurchases();

    checkPremium();

  }

  Widget feature(String text) {

    return Padding(

      padding: const EdgeInsets.symmetric(vertical: 6),

      child: Row(

        children: [

          const Icon(
            Icons.check_circle,
            color: Colors.lightBlueAccent,
          ),

          const SizedBox(width: 10),

          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),

        ],

      ),

    );

  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "AquaCalc Premium",

      child: Padding(

        padding: const EdgeInsets.all(20),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            const Text(
              "Odblokuj pełną wersję:",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            feature("Nielimitowane akwaria"),

            feature("Analiza akwarium"),

            feature("Historia nawożeń"),

            feature("Wszystkie parametry wody"),

            feature("Pełne wykresy"),

            const SizedBox(height: 30),

            const Text(
              "15 zł / miesiąc",
              style: TextStyle(
                color: Colors.lightBlueAccent,
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            if (isPremium)

              const Text(
                "Masz aktywne Premium",
                style: TextStyle(
                  color: Colors.green,
                  fontSize: 18,
                ),
              )

            else

              ElevatedButton(

                onPressed: loading ? null : buy,

                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.black,
                  backgroundColor: Colors.lightBlueAccent,
                  minimumSize: const Size(double.infinity, 50),
                ),

                child: loading
                    ? const CircularProgressIndicator()
                    : const Text(
                        "Kup Premium",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

              ),

            const SizedBox(height: 10),

            TextButton(

              onPressed: restore,

              child: const Text(
                "Przywróć zakup",
                style: TextStyle(
                  color: Colors.white,
                ),
              ),

            ),

          ],

        ),

      ),

    );

  }

}