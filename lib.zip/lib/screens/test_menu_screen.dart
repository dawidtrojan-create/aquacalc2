import 'package:flutter/material.dart';

import '../widgets/app_background.dart';
import '../models/water_parameter.dart';

import '../services/premium_service.dart';

import 'test_parameter_screen.dart';
import 'premium_screen.dart';

class TestMenuScreen extends StatefulWidget {
  const TestMenuScreen({super.key});

  @override
  State<TestMenuScreen> createState() => _TestMenuScreenState();
}

class _TestMenuScreenState extends State<TestMenuScreen> {

  bool isPremium = false;
  bool loading = true;

  final freeParameters = const [

    WaterParameter(
      name: "pH",
      unit: "",
      min: 5,
      optimalMin: 6,
      optimalMax: 7.5,
      max: 8.5,
      testDurationSeconds: 60,
    ),

    WaterParameter(
      name: "GH",
      unit: "°d",
      min: 3,
      optimalMin: 6,
      optimalMax: 8,
      max: 12,
      testDurationSeconds: 60,
    ),

    WaterParameter(
      name: "KH",
      unit: "°d",
      min: 1,
      optimalMin: 3,
      optimalMax: 6,
      max: 10,
      testDurationSeconds: 60,
    ),

    WaterParameter(
      name: "NO2",
      unit: "ppm",
      min: 0,
      optimalMin: 0,
      optimalMax: 0,
      max: 0.1,
      testDurationSeconds: 60,
    ),

    WaterParameter(
      name: "NH3",
      unit: "ppm",
      min: 0,
      optimalMin: 0,
      optimalMax: 0,
      max: 0.1,
      testDurationSeconds: 60,
    ),

    WaterParameter(
      name: "PO4",
      unit: "ppm",
      min: 0.1,
      optimalMin: 0.5,
      optimalMax: 2,
      max: 5,
      testDurationSeconds: 300,
    ),

    WaterParameter(
      name: "NO3",
      unit: "ppm",
      min: 5,
      optimalMin: 10,
      optimalMax: 25,
      max: 50,
      testDurationSeconds: 300,
    ),

  ];

  final premiumParameters = const [

    WaterParameter(
      name: "Fe",
      unit: "ppm",
      min: 0.01,
      optimalMin: 0.05,
      optimalMax: 0.1,
      max: 0.5,
      testDurationSeconds: 300,
    ),

    WaterParameter(
      name: "K",
      unit: "ppm",
      min: 5,
      optimalMin: 10,
      optimalMax: 20,
      max: 40,
      testDurationSeconds: 300,
    ),

    WaterParameter(
      name: "Mg",
      unit: "ppm",
      min: 2,
      optimalMin: 5,
      optimalMax: 10,
      max: 20,
      testDurationSeconds: 300,
    ),

    WaterParameter(
      name: "Ca",
      unit: "ppm",
      min: 10,
      optimalMin: 20,
      optimalMax: 40,
      max: 80,
      testDurationSeconds: 300,
    ),

  ];

  @override
  void initState() {
    super.initState();
    loadPremium();
  }

  Future<void> loadPremium() async {

    isPremium = await PremiumService.isPremium();

    setState(() {
      loading = false;
    });

  }

  void openParameter(WaterParameter parameter) {

    Navigator.push(

      context,

      MaterialPageRoute(

        builder: (_) => TestParameterScreen(
          parameter: parameter,
          testDurationSeconds: parameter.testDurationSeconds,
        ),

      ),

    );

  }

  Widget buildParameter(WaterParameter parameter, {bool locked = false}) {

    return Card(

      color: Colors.white,

      child: ListTile(

        title: Text(
          parameter.name,
          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),

        trailing: locked
            ? const Icon(Icons.lock, color: Colors.black)
            : null,

        onTap: () {

          if (locked) {

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const PremiumScreen(),
              ),
            );

            return;
          }

          openParameter(parameter);

        },

      ),

    );

  }

  @override
  Widget build(BuildContext context) {

    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return AppBackground(

      title: "Testy wody",

      child: ListView(

        padding: const EdgeInsets.all(16),

        children: [

          ...freeParameters.map((p) => buildParameter(p)),

          const SizedBox(height: 20),

          ...premiumParameters.map(
            (p) => buildParameter(p, locked: !isPremium),
          ),

        ],

      ),

    );

  }

}