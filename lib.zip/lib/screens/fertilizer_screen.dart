import 'package:flutter/material.dart';
import '../widgets/app_background.dart';
import '../utils/number_parser.dart';
import '../utils/aquarium_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FertilizerScreen extends StatefulWidget {
  const FertilizerScreen({super.key});

  @override
  State<FertilizerScreen> createState() => _FertilizerScreenState();
}

enum FertilizerType {
  no3,
  po4,
  k,
  fe,
  macro,
  micro,
}

class Fertilizer {
  final String name;
  final double ppmPerMlPer100L;
  final FertilizerType type;

  const Fertilizer(this.name, this.ppmPerMlPer100L, this.type);
}

class _FertilizerScreenState extends State<FertilizerScreen> {

  final volumeController = TextEditingController();
  final currentController = TextEditingController();
  final targetController = TextEditingController();

  String activeAquarium = "";

  double once = 0;
  double daily = 0;
  double weekly = 0;
  double ei3x = 0;

  FertilizerType selectedType = FertilizerType.no3;
  Fertilizer? selectedFertilizer;

  final List<Fertilizer> fertilizers = const [

    // ================= AQUAFOREST =================

    Fertilizer("Aquaforest N Boost", 1.0, FertilizerType.no3),
    Fertilizer("Aquaforest PO4 Boost", 0.1, FertilizerType.po4),
    Fertilizer("Aquaforest K Boost", 0.5, FertilizerType.k),
    Fertilizer("Aquaforest Iron Boost", 0.04, FertilizerType.fe),
    Fertilizer("Aquaforest Macro", 0.5, FertilizerType.macro),
    Fertilizer("Aquaforest Micro", 0.05, FertilizerType.micro),

    // ================= AQUA REBELL =================

    Fertilizer("Aqua Rebell Makro Basic Nitrat", 0.5, FertilizerType.no3),
    Fertilizer("Aqua Rebell Makro Spezial N", 1.0, FertilizerType.no3),
    Fertilizer("Aqua Rebell Makro Basic Phosphat", 0.1, FertilizerType.po4),
    Fertilizer("Aqua Rebell Makro Basic Kalium", 0.4, FertilizerType.k),
    Fertilizer("Aqua Rebell Mikro Basic Eisen", 0.05, FertilizerType.fe),
    Fertilizer("Aqua Rebell Makro Basic NPK", 0.5, FertilizerType.macro),
    Fertilizer("Aqua Rebell Mikro Spezial Flowgrow", 0.05, FertilizerType.micro),

    // ================= EASY LIFE =================

    Fertilizer("Easy Life Nitro", 2.0, FertilizerType.no3),
    Fertilizer("Easy Life Fosfo", 0.1, FertilizerType.po4),
    Fertilizer("Easy Life Kalium", 0.5, FertilizerType.k),
    Fertilizer("Easy Life Ferro", 0.05, FertilizerType.fe),
    Fertilizer("Easy Life ProFito", 0.05, FertilizerType.micro),

    // ================= TROPICA =================

    Fertilizer("Tropica Specialised Nutrition", 0.3, FertilizerType.macro),
    Fertilizer("Tropica Premium Nutrition", 0.05, FertilizerType.micro),

    // ================= SEACHEM =================

    Fertilizer("Seachem Nitrogen", 1.0, FertilizerType.no3),
    Fertilizer("Seachem Phosphorus", 0.05, FertilizerType.po4),
    Fertilizer("Seachem Potassium", 0.5, FertilizerType.k),
    Fertilizer("Seachem Iron", 0.1, FertilizerType.fe),
    Fertilizer("Seachem Flourish", 0.05, FertilizerType.micro),

    // ================= QUALDROP =================

    Fertilizer("QualDrop N Grow", 1.0, FertilizerType.no3),
    Fertilizer("QualDrop P Grow", 0.1, FertilizerType.po4),
    Fertilizer("QualDrop K Grow", 0.5, FertilizerType.k),
    Fertilizer("QualDrop Fe Grow", 0.05, FertilizerType.fe),
    Fertilizer("QualDrop Micro Grow", 0.05, FertilizerType.micro),
    Fertilizer("QualDrop Macro Grow", 0.5, FertilizerType.macro),

    // ================= GT AQUA =================

    Fertilizer("GT Aqua Booster N", 0.5, FertilizerType.no3),
    Fertilizer("GT Aqua Booster P", 0.1, FertilizerType.po4),
    Fertilizer("GT Aqua Booster K", 0.4, FertilizerType.k),
    Fertilizer("GT Aqua Booster Fe", 0.05, FertilizerType.fe),
    Fertilizer("GT Aqua Booster Macro", 0.5, FertilizerType.macro),
    Fertilizer("GT Aqua Booster Micro", 0.05, FertilizerType.micro),

  ];

  List<Fertilizer> get filtered =>
      fertilizers.where((f) => f.type == selectedType).toList();

  @override
  void initState() {
    super.initState();
    loadAquarium();
  }

  Future<void> loadAquarium() async {

    final prefs = await SharedPreferences.getInstance();

    activeAquarium = prefs.getString("activeAquarium") ?? "";

    if (activeAquarium.contains("|")) {

      final parts = activeAquarium.split("|");

      if (parts.length > 1) {
        volumeController.text = parts[1];
      }

    }

    setState(() {});
  }

  Future<void> calculate() async {

    if (selectedFertilizer == null) return;

    final volume = parseNumber(volumeController.text);
    final current = parseNumber(currentController.text);
    final target = parseNumber(targetController.text);

    final diff = target - current;

    if (diff <= 0 || volume <= 0) return;

    final strength = selectedFertilizer!.ppmPerMlPer100L;

    final ml = diff * volume / strength / 100;

    setState(() {

      once = ml;
      weekly = ml;
      daily = ml / 7;
      ei3x = ml / 3;

    });

    try {

      final now = DateTime.now();

      final entry =
          "${now.day.toString().padLeft(2, '0')}."
          "${now.month.toString().padLeft(2, '0')}."
          "${now.year}  "
          "${selectedFertilizer!.name}  "
          "${ml.toStringAsFixed(2)} ml";

      await AquariumStorage.addHistory(entry);

    } catch (_) {}
  }

  InputDecoration deco(String label) => InputDecoration(
    labelText: label,
    labelStyle: const TextStyle(color: Colors.black),
    filled: true,
    fillColor: Colors.white,
    enabledBorder: const OutlineInputBorder(
      borderSide: BorderSide(color: Colors.black),
    ),
    focusedBorder: const OutlineInputBorder(
      borderSide: BorderSide(color: Colors.black, width: 2),
    ),
  );

  String typeName(FertilizerType t) {
    switch (t) {
      case FertilizerType.no3: return "NO3";
      case FertilizerType.po4: return "PO4";
      case FertilizerType.k: return "K";
      case FertilizerType.fe: return "Fe";
      case FertilizerType.macro: return "Macro";
      case FertilizerType.micro: return "Micro";
    }
  }

  Widget resultLine(String label, double value) {
    return Text(
      "$label: ${value.toStringAsFixed(2)} ml",
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Nawozy – $activeAquarium",

      child: Padding(

        padding: const EdgeInsets.all(16),

        child: ListView(

          children: [

            DropdownButtonFormField(
              value: selectedType,
              decoration: deco("Parametr"),
              dropdownColor: Colors.white,
              items: FertilizerType.values.map((t) =>
                DropdownMenuItem(
                  value: t,
                  child: Text(typeName(t)),
                )
              ).toList(),
              onChanged: (v) => setState(() {
                selectedType = v!;
                selectedFertilizer = null;
              }),
            ),

            const SizedBox(height: 10),

            DropdownButtonFormField(
              value: filtered.contains(selectedFertilizer)
                  ? selectedFertilizer
                  : null,
              decoration: deco("Nawóz"),
              dropdownColor: Colors.white,
              items: filtered.map((f) =>
                DropdownMenuItem(
                  value: f,
                  child: Text(f.name),
                )
              ).toList(),
              onChanged: (v) =>
                  setState(() => selectedFertilizer = v),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: volumeController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: deco("Objętość (L)"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: currentController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: deco("Aktualne ppm"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: targetController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.black),
              decoration: deco("Docelowe ppm"),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: calculate,
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              child: const Text("Oblicz"),
            ),

            const SizedBox(height: 20),

            resultLine("Jednorazowo", once),
            resultLine("Dziennie", daily),
            resultLine("Tygodniowo", weekly),
            resultLine("EI (3x/tydz)", ei3x),

          ],

        ),

      ),

    );

  }

}