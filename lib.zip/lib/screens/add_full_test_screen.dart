import 'package:flutter/material.dart';

import '../widgets/app_background.dart';
import '../models/water_test_result.dart';
import '../services/full_water_test_service.dart';

class AddFullTestScreen extends StatefulWidget {

  const AddFullTestScreen({super.key});

  @override
  State<AddFullTestScreen> createState() => _AddFullTestScreenState();

}

class _AddFullTestScreenState extends State<AddFullTestScreen> {

  final Map<String, TextEditingController> controllers = {

    "NO3": TextEditingController(),
    "PO4": TextEditingController(),
    "K": TextEditingController(),
    "Mg": TextEditingController(),
    "Fe": TextEditingController(),
    "NO2": TextEditingController(),
    "NH3/NH4": TextEditingController(),
    "pH": TextEditingController(),
    "GH": TextEditingController(),
    "KH": TextEditingController(),
    "CO2": TextEditingController(),
    "TDS": TextEditingController(),
    "Cl2": TextEditingController(),
    "O2": TextEditingController(),

  };


  Future<void> saveTest() async {

    final Map<String, double> values = {};

    for (final entry in controllers.entries) {

      final text = entry.value.text.replaceAll(",", ".");
      final value = double.tryParse(text);

      if (value != null) {
        values[entry.key] = value;
      }

    }

    if (values.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Wprowadź przynajmniej jeden parametr"),
        ),
      );

      return;
    }

    final test = WaterTestResult(
      aquarium: "default",
      date: DateTime.now(),
      values: values,
    );

    await FullWaterTestService.saveTest(test);

    if (!mounted) return;

    for (final controller in controllers.values) {
      controller.clear();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Test zapisany"),
      ),
    );

    Navigator.pop(context);

  }


  Widget buildField(String name) {

    return Padding(

      padding: const EdgeInsets.symmetric(vertical: 6),

      child: SizedBox(

        width: 220,

        child: TextField(

          controller: controllers[name],

          keyboardType: const TextInputType.numberWithOptions(decimal: true),

          style: const TextStyle(
            color: Colors.black, // ← CZARNA CZCIONKA
          ),

          decoration: InputDecoration(

            labelText: name,

            labelStyle: const TextStyle(
              color: Colors.black, // ← CZARNA CZCIONKA
            ),

            filled: true,
            fillColor: Colors.white,

            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),

          ),

        ),

      ),

    );

  }


  @override
  void dispose() {

    for (final controller in controllers.values) {
      controller.dispose();
    }

    super.dispose();

  }


  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Dodaj test wody",

      child: Scaffold(

        backgroundColor: Colors.transparent,

        body: Center(

          child: SingleChildScrollView(

            child: Column(

              mainAxisAlignment: MainAxisAlignment.center,

              children: [

                buildField("NO3"),
                buildField("PO4"),
                buildField("K"),
                buildField("Mg"),
                buildField("Fe"),
                buildField("NO2"),
                buildField("NH3/NH4"),
                buildField("pH"),
                buildField("GH"),
                buildField("KH"),
                buildField("CO2"),
                buildField("TDS"),
                buildField("Cl2"),
                buildField("O2"),

                const SizedBox(height: 20),

                ElevatedButton(

                  onPressed: saveTest,

                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black, // ← CZARNA CZCIONKA
                  ),

                  child: const Text("ZAPISZ TEST"),

                ),

              ],

            ),

          ),

        ),

      ),

    );

  }

}