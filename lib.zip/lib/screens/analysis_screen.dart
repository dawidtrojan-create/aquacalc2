import 'package:flutter/material.dart';

import '../widgets/app_background.dart';
import '../models/water_test_result.dart';
import '../models/water_parameter.dart';

import '../services/full_water_test_service.dart';
import '../services/premium_service.dart';

import 'premium_screen.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {

  bool isPremium = false;
  bool loading = true;

  List<WaterTestResult> history = [];

  final parameters = [

    const WaterParameter(
      name: "NO3",
      unit: "ppm",
      min: 0,
      optimalMin: 10,
      optimalMax: 25,
      max: 50,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "PO4",
      unit: "ppm",
      min: 0,
      optimalMin: 0.5,
      optimalMax: 2,
      max: 5,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "Fe",
      unit: "ppm",
      min: 0,
      optimalMin: 0.05,
      optimalMax: 0.2,
      max: 0.5,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "K",
      unit: "ppm",
      min: 0,
      optimalMin: 10,
      optimalMax: 30,
      max: 50,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "pH",
      unit: "",
      min: 5.5,
      optimalMin: 6.0,
      optimalMax: 7.0,
      max: 7.5,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "GH",
      unit: "",
      min: 3,
      optimalMin: 5,
      optimalMax: 8,
      max: 12,
      testDurationSeconds: 60,
    ),

    const WaterParameter(
      name: "KH",
      unit: "",
      min: 1,
      optimalMin: 3,
      optimalMax: 6,
      max: 10,
      testDurationSeconds: 60,
    ),

  ];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {

    final premium = await PremiumService.isPremium();

    if (!premium) {

      setState(() {
        isPremium = false;
        loading = false;
      });

      return;
    }

    final data = await FullWaterTestService.getHistory();

    setState(() {

      isPremium = true;
      history = data;
      loading = false;

    });

  }

  WaterTestResult? latestTest() {

    if (history.isEmpty) return null;

    history.sort((a, b) => b.date.compareTo(a.date));

    return history.first;
  }

  Color statusColor(String text) {

    if (text.contains("Idealny")) {
      return Colors.green;
    }

    if (text.contains("Trochę")) {
      return Colors.orange;
    }

    if (text.contains("Za mało")) {
      return Colors.orange;
    }

    if (text.contains("Za dużo")) {
      return Colors.red;
    }

    if (text.contains("niebezpieczne")) {
      return Colors.red;
    }

    return Colors.white;
  }

  Widget premiumLocked() {

    return Center(

      child: Column(

        mainAxisAlignment: MainAxisAlignment.center,

        children: [

          const Icon(
            Icons.lock,
            size: 64,
            color: Colors.white,
          ),

          const SizedBox(height: 20),

          const Text(
            "Analiza dostępna w Premium",
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
            ),
          ),

          const SizedBox(height: 20),

          ElevatedButton(

            onPressed: () {

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const PremiumScreen(),
                ),
              );

            },

            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.black,
            ),

            child: const Text("Kup Premium"),

          ),

        ],

      ),

    );

  }

  Widget analysisView() {

    final test = latestTest();

    if (test == null) {

      return const Center(
        child: Text(
          "Brak danych",
          style: TextStyle(color: Colors.white),
        ),
      );

    }

    return ListView(

      padding: const EdgeInsets.all(16),

      children: parameters.map((param) {

        final value = test.values[param.name];

        if (value == null) {
          return const SizedBox();
        }

        final status = param.evaluate(value);

        return Card(

          color: Colors.white,

          child: ListTile(

            title: Text(
              param.name,
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),

            subtitle: Text(
              "$value ${param.unit}",
              style: const TextStyle(
                color: Colors.black,
              ),
            ),

            trailing: Text(
              status,
              style: TextStyle(
                color: statusColor(status),
                fontWeight: FontWeight.bold,
              ),
            ),

          ),

        );

      }).toList(),

    );

  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Analiza akwarium",

      child: loading
          ? const Center(child: CircularProgressIndicator())
          : isPremium
              ? analysisView()
              : premiumLocked(),

    );

  }

}