import 'package:flutter/material.dart';

import '../widgets/app_background.dart';
import '../utils/aquarium_storage.dart';
import '../services/premium_service.dart';

import 'premium_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {

  bool isPremium = false;
  bool loading = true;

  List<String> history = [];

  final fertilizerController = TextEditingController();
  final amountController = TextEditingController();

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {

    final premium = await PremiumService.isPremium();

    if (!premium) {

      setState(() {
        isPremium = false;
        loading = false;
      });

      return;
    }

    final hist = await AquariumStorage.getHistory();

    setState(() {

      isPremium = true;
      history = hist;
      loading = false;

    });

  }

  Future<void> addManualEntry() async {

    final fertilizer = fertilizerController.text.trim();
    final amount = amountController.text.trim();

    if (fertilizer.isEmpty || amount.isEmpty) return;

    final now = DateTime.now();

    final entry =
        "${now.day.toString().padLeft(2, '0')}."
        "${now.month.toString().padLeft(2, '0')}."
        "${now.year}  "
        "$fertilizer  "
        "$amount ml";

    await AquariumStorage.addHistory(entry);

    fertilizerController.clear();
    amountController.clear();

    final hist = await AquariumStorage.getHistory();

    setState(() {
      history = hist;
    });

  }

  Future<void> deleteEntry(int index) async {

    final confirm = await showDialog<bool>(

      context: context,

      builder: (_) => AlertDialog(

        title: const Text(
          "Usuń wpis",
          style: TextStyle(color: Colors.black),
        ),

        content: const Text(
          "Czy na pewno chcesz usunąć ten wpis?",
          style: TextStyle(color: Colors.black),
        ),

        actions: [

          TextButton(

            onPressed: () => Navigator.pop(context, false),

            child: const Text(
              "Anuluj",
              style: TextStyle(color: Colors.black),
            ),

          ),

          TextButton(

            onPressed: () => Navigator.pop(context, true),

            child: const Text(
              "Usuń",
              style: TextStyle(color: Colors.red),
            ),

          ),

        ],

      ),

    );

    if (confirm == true) {

      await AquariumStorage.deleteHistory(index);

      final hist = await AquariumStorage.getHistory();

      setState(() {
        history = hist;
      });

    }

  }

  Widget premiumLocked() {

    return Center(

      child: Column(

        mainAxisAlignment: MainAxisAlignment.center,

        children: [

          const Icon(
            Icons.lock,
            size: 64,
            color: Colors.white,
          ),

          const SizedBox(height: 20),

          const Text(
            "Historia nawożeń dostępna w Premium",
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
            ),
          ),

          const SizedBox(height: 20),

          ElevatedButton(

            onPressed: () {

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const PremiumScreen(),
                ),
              );

            },

            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.black,
            ),

            child: const Text("Kup Premium"),

          ),

        ],

      ),

    );

  }

  Widget historyView() {

    return Column(

      children: [

        Padding(

          padding: const EdgeInsets.all(16),

          child: Column(

            children: [

              TextField(

                controller: fertilizerController,

                style: const TextStyle(color: Colors.black),

                decoration: const InputDecoration(
                  labelText: "Nazwa nawozu",
                  labelStyle: TextStyle(color: Colors.black),
                  filled: true,
                  fillColor: Colors.white,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 2),
                  ),
                ),

              ),

              const SizedBox(height: 10),

              TextField(

                controller: amountController,

                keyboardType: TextInputType.number,

                style: const TextStyle(color: Colors.black),

                decoration: const InputDecoration(
                  labelText: "Ilość ml",
                  labelStyle: TextStyle(color: Colors.black),
                  filled: true,
                  fillColor: Colors.white,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 2),
                  ),
                ),

              ),

              const SizedBox(height: 10),

              ElevatedButton(

                onPressed: addManualEntry,

                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.black,
                ),

                child: const Text("Dodaj ręcznie"),

              ),

            ],

          ),

        ),

        Expanded(

          child: ListView.builder(

            padding: const EdgeInsets.all(16),

            itemCount: history.length,

            itemBuilder: (context, index) {

              return Card(

                color: Colors.white,

                child: ListTile(

                  title: Text(
                    history[index],
                    style: const TextStyle(color: Colors.black),
                  ),

                  trailing: IconButton(

                    icon: const Icon(
                      Icons.delete,
                      color: Colors.black,
                    ),

                    onPressed: () => deleteEntry(index),

                  ),

                ),

              );

            },

          ),

        ),

      ],

    );

  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "Historia nawożeń",

      child: loading
          ? const Center(child: CircularProgressIndicator())
          : isPremium
              ? historyView()
              : premiumLocked(),

    );

  }

}