import 'dart:async';
import 'package:flutter/material.dart';

import '../widgets/app_background.dart';
import '../models/water_parameter.dart';
import '../utils/timer_storage.dart';
import '../services/notification_service.dart';
import '../services/full_water_test_service.dart';

class TestParameterScreen extends StatefulWidget {

  final WaterParameter parameter;
  final int testDurationSeconds;

  const TestParameterScreen({
    super.key,
    required this.parameter,
    required this.testDurationSeconds,
  });

  @override
  State<TestParameterScreen> createState() => _TestParameterScreenState();
}

class _TestParameterScreenState extends State<TestParameterScreen> {

  final valueController = TextEditingController();

  Timer? timer;

  int secondsLeft = 0;

  bool running = false;

  String get timerKey => widget.parameter.name;


  String formatTime(int totalSeconds) {

    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;

    final minStr = minutes.toString().padLeft(2, '0');
    final secStr = seconds.toString().padLeft(2, '0');

    return "$minStr:$secStr";
  }


  @override
  void initState() {
    super.initState();
    loadTimer();
  }


  Future<void> loadTimer() async {

    final savedTimestamp = await TimerStorage.getTimer(timerKey);

    if (savedTimestamp == null) return;

    final now = DateTime.now().millisecondsSinceEpoch;

    final diff = savedTimestamp - now;

    if (diff > 0) {

      secondsLeft = (diff / 1000).floor();

      startTicking();

    } else {

      await TimerStorage.clearTimer(timerKey);

    }

  }


  Future<void> startTimer() async {

    final endTimestamp =
        DateTime.now().millisecondsSinceEpoch +
        widget.testDurationSeconds * 1000;

    await TimerStorage.saveTimer(timerKey, endTimestamp);

    secondsLeft = widget.testDurationSeconds;

    startTicking();

    NotificationService.schedule(
      id: timerKey.hashCode,
      title: "AquaCalc",
      body: "Test ${widget.parameter.name} gotowy",
      seconds: widget.testDurationSeconds,
    );
  }


  void startTicking() {

    running = true;

    timer?.cancel();

    timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) {

        if (secondsLeft <= 0) {

          timer?.cancel();

          TimerStorage.clearTimer(timerKey);

          setState(() {
            running = false;
          });

        }
        else {

          setState(() {
            secondsLeft--;
          });

        }

      },
    );

    setState(() {});
  }


  void stopTimer() {

    timer?.cancel();

    TimerStorage.clearTimer(timerKey);

    setState(() {

      running = false;

      secondsLeft = 0;

    });

  }


  Future<void> saveResult() async {

    final text = valueController.text.replaceAll(",", ".");

    final value = double.tryParse(text);

    if (value == null) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Niepoprawna wartość")),
      );

      return;

    }

    await FullWaterTestService.saveParameterResult(
      parameter: widget.parameter.name,
      value: value,
    );

    if (!mounted) return;

    valueController.clear();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Zapisano ${widget.parameter.name}: $value"),
      ),
    );

  }


  @override
  void dispose() {

    timer?.cancel();

    valueController.dispose();

    super.dispose();

  }


  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: widget.parameter.name,

      child: Scaffold(

        backgroundColor: Colors.transparent,

        body: Center(

          child: Column(

            mainAxisAlignment: MainAxisAlignment.center,

            children: [

              const Text(
                "Pozostały czas",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                formatTime(secondsLeft),
                style: const TextStyle(
                  fontSize: 64,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 30),

              if (!running)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black, // ← CZARNA CZCIONKA
                  ),
                  onPressed: startTimer,
                  child: const Text("START TESTU"),
                ),

              if (running)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black, // ← CZARNA CZCIONKA
                    backgroundColor: Colors.red,
                  ),
                  onPressed: stopTimer,
                  child: const Text("STOP"),
                ),

              const SizedBox(height: 40),

              SizedBox(
                width: 220,
                child: TextField(
                  controller: valueController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(

                    labelText: "Wynik testu",

                    labelStyle: const TextStyle(
                      color: Colors.black,
                    ),

                    filled: true,
                    fillColor: Colors.white,

                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.black, // ← CZARNA OBRAMÓWKA
                      ),
                      borderRadius: BorderRadius.circular(6),
                    ),

                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.black, // ← CZARNA OBRAMÓWKA
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(6),
                    ),

                  ),
                ),
              ),

              const SizedBox(height: 10),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.black, // ← CZARNA CZCIONKA
                ),
                onPressed: saveResult,
                child: const Text("ZAPISZ WYNIK"),
              ),

            ],

          ),

        ),

      ),

    );

  }

}