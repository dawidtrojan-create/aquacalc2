import 'package:flutter/material.dart';

import '../widgets/app_background.dart';

import 'premium_screen.dart';
import 'aquariums_screen.dart';
import 'test_menu_screen.dart';
import 'add_full_test_screen.dart';
import 'charts_screen.dart';
import 'analysis_screen.dart';
import 'fertilizer_screen.dart';
import 'ro_mix_screen.dart';
import 'substrate_screen.dart';
import 'history_screen.dart';

class HomeScreen extends StatelessWidget {

  const HomeScreen({super.key});

  Widget buildButton({

    required BuildContext context,
    required String title,
    required IconData icon,
    required Widget screen,

  }) {

    return Card(

      child: ListTile(

        leading: Icon(
          icon,
          size: 32,
          color: Colors.black,
        ),

        title: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),

        trailing: const Icon(
          Icons.arrow_forward_ios,
          color: Colors.black,
        ),

        onTap: () {

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => screen,
            ),
          );

        },

      ),

    );

  }

  @override
  Widget build(BuildContext context) {

    return AppBackground(

      title: "AquaCalc",

      child: Scaffold(

        backgroundColor: Colors.transparent,

        body: ListView(

          padding: const EdgeInsets.all(16),

          children: [

            // PREMIUM
            buildButton(
              context: context,
              title: "AquaCalc Premium",
              icon: Icons.workspace_premium,
              screen: const PremiumScreen(),
            ),

            // Moje Akwaria
            buildButton(
              context: context,
              title: "Moje akwaria",
              icon: Icons.set_meal,
              screen: AquariumsScreen(),
            ),

            // Testy wody
            buildButton(
              context: context,
              title: "Testy wody",
              icon: Icons.water,
              screen: TestMenuScreen(),
            ),

            // Wykresy parametrów
            buildButton(
              context: context,
              title: "Wykresy parametrów",
              icon: Icons.show_chart,
              screen: const ChartsScreen(),
            ),

            // Analiza akwarium
            buildButton(
              context: context,
              title: "Analiza akwarium",
              icon: Icons.analytics,
              screen: AnalysisScreen(),
            ),

            // Kalkulator nawozów
            buildButton(
              context: context,
              title: "Kalkulator nawozów",
              icon: Icons.science,
              screen: const FertilizerScreen(),
            ),

            // Kalkulator RO
            buildButton(
              context: context,
              title: "Kalkulator RO / kran",
              icon: Icons.water_drop,
              screen: const RoMixScreen(),
            ),

            // Kalkulator podłoża
            buildButton(
              context: context,
              title: "Kalkulator podłoża",
              icon: Icons.landscape,
              screen: const SubstrateScreen(),
            ),

            // Historia nawożenia
            buildButton(
              context: context,
              title: "Historia nawożenia",
              icon: Icons.history,
              screen: const HistoryScreen(),
            ),

          ],

        ),

      ),

    );

  }

}