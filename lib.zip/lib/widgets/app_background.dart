import 'package:flutter/material.dart';

class AppBackground extends StatelessWidget {

  final String title;
  final Widget child;

  const AppBackground({
    super.key,
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Colors.transparent,

      appBar: AppBar(

        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white, // ← TYLKO TO ZMIENIONE
          ),
        ),

        backgroundColor: Colors.black.withOpacity(0.3),

        elevation: 0,

        iconTheme: const IconThemeData(
          color: Colors.white, // ← strzałka back też biała
        ),

      ),

      body: Stack(

        children: [

          Positioned.fill(
            child: Image.asset(
              "assets/images/aquarium_bg.png",
              fit: BoxFit.cover,
            ),
          ),

          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(0.4),
            ),
          ),

          Positioned.fill(
            child: SafeArea(
              child: child,
            ),
          ),

        ],

      ),

    );

  }

}