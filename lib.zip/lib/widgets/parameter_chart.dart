import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/water_test_result.dart';

class ParameterChart extends StatelessWidget {

  final List<WaterTestResult> history;
  final String parameter;

  const ParameterChart({
    super.key,
    required this.history,
    required this.parameter,
  });

  @override
  Widget build(BuildContext context) {

    final filtered = history
        .where((e) => e.values.containsKey(parameter))
        .toList();

    if (filtered.isEmpty) {

      return const Center(
        child: Text(
          "Brak danych dla parametru",
          style: TextStyle(
            color: Colors.black,
            fontSize: 16,
          ),
        ),
      );

    }

    final spots = <FlSpot>[];

    for (int i = 0; i < filtered.length; i++) {

      final value = filtered[i].values[parameter]!;

      spots.add(
        FlSpot(i.toDouble(), value),
      );

    }

    return Padding(
      padding: const EdgeInsets.all(16),

      child: LineChart(

        LineChartData(

          backgroundColor: Colors.white,

          borderData: FlBorderData(
            show: true,
            border: Border.all(color: Colors.black),
          ),

          titlesData: FlTitlesData(

            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 40,
              ),
            ),

            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
              ),
            ),

            rightTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),

            topTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),

          ),

          lineBarsData: [

            LineChartBarData(

              spots: spots,

              isCurved: true,

              color: Colors.blue,

              barWidth: 3,

              dotData: FlDotData(show: true),

            ),

          ],

        ),

      ),

    );

  }

}