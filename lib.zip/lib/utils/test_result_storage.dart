import 'package:shared_preferences/shared_preferences.dart';
import '../models/test_result.dart';

class TestResultStorage {

  static const key = "test_results";

  static Future<void> save(TestResult result) async {

    final prefs = await SharedPreferences.getInstance();

    final list = prefs.getStringList(key) ?? [];

    list.add(result.toStorageString());

    await prefs.setStringList(key, list);

  }

  static Future<List<TestResult>> load() async {

    final prefs = await SharedPreferences.getInstance();

    final list = prefs.getStringList(key) ?? [];

    return list
        .map((e) => TestResult.fromStorageString(e))
        .toList();

  }

}