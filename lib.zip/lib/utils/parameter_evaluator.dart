class ParameterEvaluation {

  final String status;
  final String title;
  final String description;
  final String recommendation;

  ParameterEvaluation({
    required this.status,
    required this.title,
    required this.description,
    required this.recommendation,
  });

}

class ParameterEvaluator {

  static ParameterEvaluation evaluate(String parameter, double value) {

    switch (parameter) {

      case "NO3":

        if (value < 5) {
          return ParameterEvaluation(
            status: "KRYTYCZNIE NISKI",
            title: "Bardzo za mało NO3",
            description:
                "Rośliny nie mają wystarczającej ilości azotu. "
                "Może dojść do zahamowania wzrostu i rozwoju glonów.",
            recommendation:
                "Natychmiast zwiększ nawożenie NO3. Cel: 10–20 ppm.",
          );
        }

        if (value < 10) {
          return ParameterEvaluation(
            status: "ZA MAŁO",
            title: "Za mało NO3",
            description:
                "Rośliny mogą rosnąć wolniej i wykazywać niedobory.",
            recommendation:
                "Zwiększ dawkowanie nawozu azotowego.",
          );
        }

        if (value <= 20) {
          return ParameterEvaluation(
            status: "IDEALNIE",
            title: "Idealny poziom NO3",
            description:
                "Optymalny poziom dla zdrowego wzrostu roślin.",
            recommendation:
                "Utrzymuj obecny poziom.",
          );
        }

        if (value <= 30) {
          return ParameterEvaluation(
            status: "ZA DUŻO",
            title: "Za dużo NO3",
            description:
                "Może zwiększać ryzyko glonów.",
            recommendation:
                "Zmniejsz nawożenie lub podmień wodę.",
          );
        }

        return ParameterEvaluation(
          status: "NIEBEZPIECZNY",
          title: "Niebezpiecznie wysoki NO3",
          description:
              "Może być szkodliwy dla ryb.",
          recommendation:
              "Wykonaj podmianę 30–50% wody.",
        );

      case "PO4":

        if (value < 0.1) {
          return ParameterEvaluation(
            status: "ZA MAŁO",
            title: "Za mało PO4",
            description:
                "Rośliny nie mogą prawidłowo rosnąć.",
            recommendation:
                "Zwiększ nawożenie PO4.",
          );
        }

        if (value <= 1.5) {
          return ParameterEvaluation(
            status: "IDEALNIE",
            title: "Idealny poziom PO4",
            description:
                "Optymalny poziom dla roślin.",
            recommendation:
                "Utrzymuj obecny poziom.",
          );
        }

        return ParameterEvaluation(
          status: "ZA DUŻO",
          title: "Za dużo PO4",
          description:
              "Może powodować glony.",
          recommendation:
              "Zmniejsz nawożenie.",
        );

      default:

        return ParameterEvaluation(
          status: "BRAK DANYCH",
          title: parameter,
          description: "Brak zdefiniowanych zakresów.",
          recommendation: "",
        );

    }

  }

}