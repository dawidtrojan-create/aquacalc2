import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class AquariumStorage {

  static const String aquariumsKey = "aquariums";
  static const String activeKey = "activeAquarium";

  static const String fertilizerHistoryKey = "fertilizer_history";

  // ================= ACTIVE AQUARIUM =================

  static Future<String?> getActiveAquarium() async {

    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(activeKey);

  }

  static Future<void> setActiveAquarium(String aquarium) async {

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(activeKey, aquarium);

  }

  // ================= FERTILIZER HISTORY =================

  static Future<void> addHistory(String entry) async {

    final prefs = await SharedPreferences.getInstance();

    final activeAquarium = prefs.getString(activeKey) ?? "default";

    final jsonString = prefs.getString(fertilizerHistoryKey);

    List<Map<String, dynamic>> history = [];

    if (jsonString != null) {

      history = List<Map<String, dynamic>>.from(
        json.decode(jsonString),
      );

    }

    history.insert(0, {

      "aquarium": activeAquarium,
      "entry": entry,

    });

    await prefs.setString(
      fertilizerHistoryKey,
      json.encode(history),
    );

  }

  static Future<List<String>> getHistory() async {

    final prefs = await SharedPreferences.getInstance();

    final activeAquarium = prefs.getString(activeKey) ?? "default";

    final jsonString = prefs.getString(fertilizerHistoryKey);

    if (jsonString == null) return [];

    final List decoded = json.decode(jsonString);

    final filtered = decoded
        .where((e) => e["aquarium"] == activeAquarium)
        .map<String>((e) => e["entry"] as String)
        .toList();

    return filtered;

  }

  static Future<void> deleteHistory(int index) async {

    final prefs = await SharedPreferences.getInstance();

    final activeAquarium = prefs.getString(activeKey) ?? "default";

    final jsonString = prefs.getString(fertilizerHistoryKey);

    if (jsonString == null) return;

    List<Map<String, dynamic>> history =
        List<Map<String, dynamic>>.from(
      json.decode(jsonString),
    );

    final filteredIndexes = <int>[];

    for (int i = 0; i < history.length; i++) {

      if (history[i]["aquarium"] == activeAquarium) {

        filteredIndexes.add(i);

      }

    }

    if (index >= 0 && index < filteredIndexes.length) {

      history.removeAt(filteredIndexes[index]);

    }

    await prefs.setString(
      fertilizerHistoryKey,
      json.encode(history),
    );

  }

}