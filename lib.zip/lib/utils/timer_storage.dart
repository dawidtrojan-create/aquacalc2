import 'package:shared_preferences/shared_preferences.dart';

class TimerStorage {

  static Future<void> saveTimer(String parameter, int endTime) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt("timer_$parameter", endTime);
  }

  static Future<int?> getTimer(String parameter) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt("timer_$parameter");
  }

  static Future<void> clearTimer(String parameter) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove("timer_$parameter");
  }

}