double parseNumber(String text) {

  if (text.isEmpty) return 0;

  text = text.replaceAll(',', '.');

  return double.tryParse(text) ?? 0;

}
