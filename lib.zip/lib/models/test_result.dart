class TestResult {

  final String aquarium;
  final String parameter;
  final double value;
  final String unit;
  final DateTime date;

  TestResult({
    required this.aquarium,
    required this.parameter,
    required this.value,
    required this.unit,
    required this.date,
  });

  String toStorageString() {
    return "$aquarium|$parameter|$value|$unit|${date.millisecondsSinceEpoch}";
  }

  static TestResult fromStorageString(String s) {

    final parts = s.split("|");

    return TestResult(
      aquarium: parts[0],
      parameter: parts[1],
      value: double.parse(parts[2]),
      unit: parts[3],
      date: DateTime.fromMillisecondsSinceEpoch(
        int.parse(parts[4]),
      ),
    );
  }

}