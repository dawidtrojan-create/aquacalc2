class WaterParameter {
  final String name;
  final String unit;
  final double min;
  final double optimalMin;
  final double optimalMax;
  final double max;
  final int testDurationSeconds;

  const WaterParameter({
    required this.name,
    required this.unit,
    required this.min,
    required this.optimalMin,
    required this.optimalMax,
    required this.max,
    required this.testDurationSeconds,
  });

  String evaluate(double value) {
    if (value < min) {
      return "Bardzo za mało — niebezpieczne dla roślin";
    }
    if (value < optimalMin) {
      return "Za mało — rośliny mogą głodować";
    }
    if (value <= optimalMax) {
      return "Idealny poziom";
    }
    if (value <= max) {
      return "Trochę za dużo";
    }
    return "Za dużo — niebezpieczne dla ryb";
  }
}