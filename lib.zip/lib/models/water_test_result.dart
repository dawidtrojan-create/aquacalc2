class WaterTestResult {

  final String aquarium;
  final DateTime date;
  final Map<String, double> values;

  WaterTestResult({
    required this.aquarium,
    required this.date,
    required this.values,
  });

  Map<String, dynamic> toJson() {
    return {
      "aquarium": aquarium,
      "date": date.toIso8601String(),
      "values": values,
    };
  }

  factory WaterTestResult.fromJson(Map<String, dynamic> json) {

    final values = Map<String, double>.from(
      json["values"].map(
        (key, value) => MapEntry(key, value.toDouble()),
      ),
    );

    return WaterTestResult(
      aquarium: json["aquarium"],
      date: DateTime.parse(json["date"]),
      values: values,
    );
  }

}