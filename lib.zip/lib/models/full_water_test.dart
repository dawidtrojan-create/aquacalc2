class FullWaterTest {

  final String aquarium;
  final DateTime date;

  final double? no3;
  final double? po4;
  final double? k;
  final double? fe;
  final double? mg;
  final double? ca;
  final double? gh;
  final double? kh;
  final double? ph;
  final double? nh3;
  final double? no2;

  FullWaterTest({
    required this.aquarium,
    required this.date,
    this.no3,
    this.po4,
    this.k,
    this.fe,
    this.mg,
    this.ca,
    this.gh,
    this.kh,
    this.ph,
    this.nh3,
    this.no2,
  });

  Map<String, dynamic> toJson() {
    return {
      "aquarium": aquarium,
      "date": date.toIso8601String(),
      "no3": no3,
      "po4": po4,
      "k": k,
      "fe": fe,
      "mg": mg,
      "ca": ca,
      "gh": gh,
      "kh": kh,
      "ph": ph,
      "nh3": nh3,
      "no2": no2,
    };
  }

  factory FullWaterTest.fromJson(Map<String, dynamic> json) {

    double? parse(dynamic value) {
      if (value == null) return null;
      return (value as num).toDouble();
    }

    return FullWaterTest(
      aquarium: json["aquarium"],
      date: DateTime.parse(json["date"]),
      no3: parse(json["no3"]),
      po4: parse(json["po4"]),
      k: parse(json["k"]),
      fe: parse(json["fe"]),
      mg: parse(json["mg"]),
      ca: parse(json["ca"]),
      gh: parse(json["gh"]),
      kh: parse(json["kh"]),
      ph: parse(json["ph"]),
      nh3: parse(json["nh3"]),
      no2: parse(json["no2"]),
    );
  }

}