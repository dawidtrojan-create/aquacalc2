import '../models/water_parameter.dart';

const waterParameters = [

  // MAKRO

  WaterParameter(
    name: "NO3",
    unit: "mg/L",
    min: 5,
    optimalMin: 10,
    optimalMax: 20,
    max: 30,
    testDurationSeconds: 300,
  ),

  WaterParameter(
    name: "PO4",
    unit: "mg/L",
    min: 0.1,
    optimalMin: 0.5,
    optimalMax: 1.5,
    max: 3,
    testDurationSeconds: 600,
  ),

  WaterParameter(
    name: "K",
    unit: "mg/L",
    min: 5,
    optimalMin: 10,
    optimalMax: 20,
    max: 30,
    testDurationSeconds: 0,
  ),

  WaterParameter(
    name: "Mg",
    unit: "mg/L",
    min: 3,
    optimalMin: 5,
    optimalMax: 10,
    max: 20,
    testDurationSeconds: 0,
  ),

  // MIKRO

  WaterParameter(
    name: "Fe",
    unit: "mg/L",
    min: 0.02,
    optimalMin: 0.05,
    optimalMax: 0.1,
    max: 0.2,
    testDurationSeconds: 300,
  ),

  // TOKSYCZNE

  WaterParameter(
    name: "NO2",
    unit: "mg/L",
    min: 0,
    optimalMin: 0,
    optimalMax: 0,
    max: 0.1,
    testDurationSeconds: 180,
  ),

  WaterParameter(
    name: "NH3/NH4",
    unit: "mg/L",
    min: 0,
    optimalMin: 0,
    optimalMax: 0,
    max: 0.1,
    testDurationSeconds: 300,
  ),

  // PARAMETRY WODY

  WaterParameter(
    name: "pH",
    unit: "",
    min: 5.5,
    optimalMin: 6.0,
    optimalMax: 7.5,
    max: 8.5,
    testDurationSeconds: 0,
  ),

  WaterParameter(
    name: "GH",
    unit: "°d",
    min: 3,
    optimalMin: 5,
    optimalMax: 12,
    max: 20,
    testDurationSeconds: 0,
  ),

  WaterParameter(
    name: "KH",
    unit: "°d",
    min: 1,
    optimalMin: 3,
    optimalMax: 8,
    max: 15,
    testDurationSeconds: 0,
  ),

  // DODATKOWE

  WaterParameter(
    name: "CO2",
    unit: "mg/L",
    min: 10,
    optimalMin: 20,
    optimalMax: 30,
    max: 40,
    testDurationSeconds: 0,
  ),

  WaterParameter(
    name: "TDS",
    unit: "ppm",
    min: 100,
    optimalMin: 150,
    optimalMax: 300,
    max: 500,
    testDurationSeconds: 0,
  ),

  WaterParameter(
    name: "Cl2",
    unit: "mg/L",
    min: 0,
    optimalMin: 0,
    optimalMax: 0,
    max: 0.02,
    testDurationSeconds: 0,
  ),

  WaterParameter(
    name: "O2",
    unit: "mg/L",
    min: 4,
    optimalMin: 6,
    optimalMax: 8,
    max: 12,
    testDurationSeconds: 0,
  ),

];