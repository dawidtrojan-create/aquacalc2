import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {

  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings settings =
        InitializationSettings(android: androidSettings);

    await _notifications.initialize(settings);

    await _notifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }


  static Future<void> show({
    required int id,
    required String title,
    required String body,
  }) async {

    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(

      'test_channel',
      'Testy wody',

      channelDescription: 'Powiadomienia testów wody',

      importance: Importance.max,
      priority: Priority.high,

      playSound: true, // ← DŹWIĘK

      enableVibration: true, // ← WIBRACJA

      ticker: 'Test gotowy',

    );

    const NotificationDetails details =
        NotificationDetails(android: androidDetails);

    await _notifications.show(
      id,
      title,
      body,
      details,
    );
  }


  static void schedule({
    required int id,
    required String title,
    required String body,
    required int seconds,
  }) {

    Timer(Duration(seconds: seconds), () {

      show(
        id: id,
        title: title,
        body: body,
      );

    });

  }

}