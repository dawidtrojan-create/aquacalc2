import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/water_test_result.dart';
import '../utils/aquarium_storage.dart';

class FullWaterTestService {

  static const String key = "full_water_tests";

  // ================= SAVE PARAMETER =================

  static Future<void> saveParameterResult({
    required String parameter,
    required double value,
  }) async {

    final prefs = await SharedPreferences.getInstance();

    final activeAquarium =
        await AquariumStorage.getActiveAquarium() ?? "default";

    final jsonString = prefs.getString(key);

    List<WaterTestResult> tests = [];

    if (jsonString != null) {

      final List decoded = json.decode(jsonString);

      tests = decoded
          .map((e) => WaterTestResult.fromJson(e))
          .toList();

    }

    final now = DateTime.now();

    WaterTestResult? today;

    for (final test in tests.reversed) {

      if (test.aquarium == activeAquarium &&
          test.date.year == now.year &&
          test.date.month == now.month &&
          test.date.day == now.day) {

        today = test;
        break;

      }

    }

    if (today == null) {

      today = WaterTestResult(
        aquarium: activeAquarium,
        date: now,
        values: {},
      );

      tests.add(today);

    }

    today.values[parameter] = value;

    await prefs.setString(
      key,
      json.encode(
        tests.map((e) => e.toJson()).toList(),
      ),
    );

  }

  // ================= GET HISTORY =================

  static Future<List<WaterTestResult>> getHistory() async {

    final prefs = await SharedPreferences.getInstance();

    final activeAquarium =
        await AquariumStorage.getActiveAquarium() ?? "default";

    final jsonString = prefs.getString(key);

    if (jsonString == null) return [];

    final List decoded = json.decode(jsonString);

    final allTests = decoded
        .map((e) => WaterTestResult.fromJson(e))
        .toList();

    final filtered = allTests
        .where((test) => test.aquarium == activeAquarium)
        .toList();

    return filtered;

  }

  // ================= SAVE FULL TEST =================

  static Future<void> saveTest(WaterTestResult test) async {

    final prefs = await SharedPreferences.getInstance();

    final activeAquarium =
        await AquariumStorage.getActiveAquarium() ?? "default";

    final jsonString = prefs.getString(key);

    List<WaterTestResult> tests = [];

    if (jsonString != null) {

      final List decoded = json.decode(jsonString);

      tests = decoded
          .map((e) => WaterTestResult.fromJson(e))
          .toList();

    }

    final newTest = WaterTestResult(
      aquarium: activeAquarium,
      date: test.date,
      values: test.values,
    );

    tests.add(newTest);

    await prefs.setString(
      key,
      json.encode(
        tests.map((e) => e.toJson()).toList(),
      ),
    );

  }

  // ================= SAVE ALL =================

  static Future<void> saveAll(List<WaterTestResult> tests) async {

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      key,
      json.encode(
        tests.map((e) => e.toJson()).toList(),
      ),
    );

  }

}