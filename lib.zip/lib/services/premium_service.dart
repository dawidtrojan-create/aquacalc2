import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PremiumService {

  static const String productId = "aquacalc_premium";
  static const String storageKey = "isPremium";

  static final InAppPurchase _iap = InAppPurchase.instance;

  static StreamSubscription<List<PurchaseDetails>>? _subscription;

  /// 🔥 ZMIEŃ NA false przed publikacją produkcyjną
  static const bool enablePremiumForTesters = true;

  static Future<void> init() async {

    // 🔥 automatyczne premium dla testerów
    if (enablePremiumForTesters) {
      await _setPremium(true);
    }

    final available = await _iap.isAvailable();

    if (!available) return;

    _subscription = _iap.purchaseStream.listen(
      _listenToPurchaseUpdated,
      onDone: () => _subscription?.cancel(),
      onError: (_) {},
    );

    await restorePurchases();

  }

  static Future<bool> isPremium() async {

    // 🔥 testerzy zawsze premium
    if (enablePremiumForTesters) {
      return true;
    }

    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(storageKey) ?? false;

  }

  static Future<void> _setPremium(bool value) async {

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(storageKey, value);

  }

  static Future<void> buyPremium() async {

    final ProductDetailsResponse response =
        await _iap.queryProductDetails({productId});

    if (response.notFoundIDs.isNotEmpty) return;

    final product = response.productDetails.first;

    final purchaseParam = PurchaseParam(
      productDetails: product,
    );

    await _iap.buyNonConsumable(
      purchaseParam: purchaseParam,
    );

  }

  static Future<void> restorePurchases() async {

    await _iap.restorePurchases();

  }

  static void _listenToPurchaseUpdated(
      List<PurchaseDetails> purchases) async {

    for (final purchase in purchases) {

      if (purchase.productID == productId) {

        if (purchase.status == PurchaseStatus.purchased ||
            purchase.status == PurchaseStatus.restored) {

          await _setPremium(true);

        }

        if (purchase.pendingCompletePurchase) {

          await _iap.completePurchase(purchase);

        }

      }

    }

  }

  static void dispose() {

    _subscription?.cancel();

  }

}