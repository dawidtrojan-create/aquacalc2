import '../models/water_test_result.dart';

class AnalysisService {

  /// TREND parametru (czy rośnie, spada, stabilny)
  static String calculateTrend(
    List<WaterTestResult> history,
    String parameter,
  ) {

    final values = history
        .map((e) => e.values[parameter])
        .whereType<double>()
        .toList();

    if (values.length < 2) return "Za mało danych";

    final first = values.first;
    final last = values.last;

    final diff = last - first;

    if (diff > 0.5) {
      return "⬆ Rośnie";
    } else if (diff < -0.5) {
      return "⬇ Spada";
    } else {
      return "➡ Stabilny";
    }

  }

  /// Analiza relacji parametrów (np NO3:PO4)
  static String analyzeRelation(List<WaterTestResult> history) {

    if (history.isEmpty) return "Brak danych";

    final last = history.last;

    final no3 = last.values["NO3"];
    final po4 = last.values["PO4"];
    final k = last.values["K"];

    String result = "";

    if (no3 != null && po4 != null && po4 > 0) {

      final ratio = no3 / po4;

      result += "NO3:PO4 = ${ratio.toStringAsFixed(1)}\n";

      if (ratio < 5) {
        result += "Za mało NO3 względem PO4\n";
      } else if (ratio > 20) {
        result += "Za dużo NO3 względem PO4\n";
      } else {
        result += "Relacja NO3:PO4 dobra\n";
      }

    }

    if (k != null && no3 != null) {

      final ratio = k / no3;

      result += "\nK:NO3 = ${ratio.toStringAsFixed(1)}\n";

      if (ratio < 0.5) {
        result += "Za mało potasu\n";
      } else if (ratio > 2) {
        result += "Za dużo potasu\n";
      } else {
        result += "Relacja K:NO3 dobra\n";
      }

    }

    return result;

  }

}